<?php
/**
 * Displays the top widget area.
 */

if ( is_active_sidebar( 'top-sidebar' ) ) :
    dynamic_sidebar( 'top-sidebar' );
endif;
