$(document).ready(function() {
    $(".hamburger").click(function() {
        $(".links").toggleClass("open");
    });
    $(window).scroll(function() {
        $(".links").removeClass("open");
        event.preventDefault();
    });
});
